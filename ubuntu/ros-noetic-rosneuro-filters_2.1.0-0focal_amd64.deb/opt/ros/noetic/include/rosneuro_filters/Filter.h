#ifndef ROSNEURO_FILTERS_FILTER_H
#define ROSNEURO_FILTERS_FILTER_H

#include "rosneuro_filters/Filter.hpp"

#endif
