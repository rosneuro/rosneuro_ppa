#ifndef ROSNEURO_FILTERS_FILTERCHAIN_H_
#define ROSNEURO_FILTERS_FILTERCHAIN_H_

#include "rosneuro_filters/FilterChain.hpp"

#endif
