#ifndef ROSNEURO_FILTERS_LAPLACIAN_H
#define ROSNEURO_FILTERS_LAPLACIAN_H

#include "rosneuro_filters_laplacian/Laplacian.hpp"

#endif
