#ifndef ROSNEURO_BUFFER_H
#define ROSNEURO_BUFFER_H

#include "rosneuro_buffers/Buffer.hpp"

#endif
