#ifndef ROSNEURO_FILTERS_DC_H
#define ROSNEURO_FILTERS_DC_H

#include "rosneuro_filters/Dc.hpp"

#endif
