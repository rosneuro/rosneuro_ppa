// Auto-generated. Do not edit!

// (in-package rosneuro_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let NeuroDataFloat = require('./NeuroDataFloat.js');
let NeuroDataInt32 = require('./NeuroDataInt32.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class NeuroOutput {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.softpredict = null;
      this.hardpredict = null;
      this.class_labels = null;
      this.decoder_type = null;
      this.decoder_path = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('softpredict')) {
        this.softpredict = initObj.softpredict
      }
      else {
        this.softpredict = new NeuroDataFloat();
      }
      if (initObj.hasOwnProperty('hardpredict')) {
        this.hardpredict = initObj.hardpredict
      }
      else {
        this.hardpredict = new NeuroDataInt32();
      }
      if (initObj.hasOwnProperty('class_labels')) {
        this.class_labels = initObj.class_labels
      }
      else {
        this.class_labels = [];
      }
      if (initObj.hasOwnProperty('decoder_type')) {
        this.decoder_type = initObj.decoder_type
      }
      else {
        this.decoder_type = '';
      }
      if (initObj.hasOwnProperty('decoder_path')) {
        this.decoder_path = initObj.decoder_path
      }
      else {
        this.decoder_path = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type NeuroOutput
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [softpredict]
    bufferOffset = NeuroDataFloat.serialize(obj.softpredict, buffer, bufferOffset);
    // Serialize message field [hardpredict]
    bufferOffset = NeuroDataInt32.serialize(obj.hardpredict, buffer, bufferOffset);
    // Serialize message field [class_labels]
    bufferOffset = _arraySerializer.string(obj.class_labels, buffer, bufferOffset, null);
    // Serialize message field [decoder_type]
    bufferOffset = _serializer.string(obj.decoder_type, buffer, bufferOffset);
    // Serialize message field [decoder_path]
    bufferOffset = _serializer.string(obj.decoder_path, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type NeuroOutput
    let len;
    let data = new NeuroOutput(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [softpredict]
    data.softpredict = NeuroDataFloat.deserialize(buffer, bufferOffset);
    // Deserialize message field [hardpredict]
    data.hardpredict = NeuroDataInt32.deserialize(buffer, bufferOffset);
    // Deserialize message field [class_labels]
    data.class_labels = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [decoder_type]
    data.decoder_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [decoder_path]
    data.decoder_path = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += NeuroDataFloat.getMessageSize(object.softpredict);
    length += NeuroDataInt32.getMessageSize(object.hardpredict);
    object.class_labels.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += _getByteLength(object.decoder_type);
    length += _getByteLength(object.decoder_path);
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rosneuro_msgs/NeuroOutput';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '882238bbda5d3d3c1295fd2f1765efcf';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # NeuroOutput Message
    
    # Header
    Header header
    
    # Output
    # decoder prediction (e.g., probabilities, regression)
    
    NeuroDataFloat softpredict
    NeuroDataInt32 hardpredict
    # discrete preditiction
    
    # Info
    string[] class_labels	
    # Labels for the classified classes
    string decoder_type	
    # Type of decoder [description]
    string decoder_path	
    # Real path of the decoder [path]
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: rosneuro_msgs/NeuroDataFloat
    NeuroDataInfo info
    float32[] data
    
    
    
    ================================================================================
    MSG: rosneuro_msgs/NeuroDataInfo
    # NeuroDataInfo Message
    
    uint16    nsamples
    uint16    nchannels
    uint16    stride
    string    unit
    string    transducter
    string    prefiltering		# Hardware prefiltering
    uint8     isint
    float64[] minmax
    string[]  labels				# Labels of channels
    
    ================================================================================
    MSG: rosneuro_msgs/NeuroDataInt32
    NeuroDataInfo info
    int32[] data
    
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new NeuroOutput(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.softpredict !== undefined) {
      resolved.softpredict = NeuroDataFloat.Resolve(msg.softpredict)
    }
    else {
      resolved.softpredict = new NeuroDataFloat()
    }

    if (msg.hardpredict !== undefined) {
      resolved.hardpredict = NeuroDataInt32.Resolve(msg.hardpredict)
    }
    else {
      resolved.hardpredict = new NeuroDataInt32()
    }

    if (msg.class_labels !== undefined) {
      resolved.class_labels = msg.class_labels;
    }
    else {
      resolved.class_labels = []
    }

    if (msg.decoder_type !== undefined) {
      resolved.decoder_type = msg.decoder_type;
    }
    else {
      resolved.decoder_type = ''
    }

    if (msg.decoder_path !== undefined) {
      resolved.decoder_path = msg.decoder_path;
    }
    else {
      resolved.decoder_path = ''
    }

    return resolved;
    }
};

module.exports = NeuroOutput;
