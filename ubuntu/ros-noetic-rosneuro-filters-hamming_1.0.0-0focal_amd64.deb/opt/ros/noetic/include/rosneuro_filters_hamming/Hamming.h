#ifndef ROSNEURO_FILTERS_HAMMING_H
#define ROSNEURO_FILTERS_HAMMING_H

#include "rosneuro_filters_hamming/Hamming.hpp"

#endif
