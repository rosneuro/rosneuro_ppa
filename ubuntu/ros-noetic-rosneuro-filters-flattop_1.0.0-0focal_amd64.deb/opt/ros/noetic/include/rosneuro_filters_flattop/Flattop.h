#ifndef ROSNEURO_FILTERS_FLATTOP_H
#define ROSNEURO_FILTERS_FLATTOP_H

#include "rosneuro_filters_flattop/Flattop.hpp"
  
#endif
