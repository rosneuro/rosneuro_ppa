
"use strict";

let GetAcquisitionInfo = require('./GetAcquisitionInfo.js')

module.exports = {
  GetAcquisitionInfo: GetAcquisitionInfo,
};
