from ._GetAcquisitionInfo import *
